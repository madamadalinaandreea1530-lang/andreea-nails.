// Configurare publică Supabase. Cheia publishable este destinată browserului.
window.AN_CONFIG = {
  SUPABASE_URL: "https://wkchngcbghkwyvvwyoam.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "sb_publishable_s4TEhDmaDBq7pnLCerptDw_GCXLd53K",
  EDGE_FUNCTION_NAME: "quik-worker"
};